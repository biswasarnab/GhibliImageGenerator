package in.biswasarnab.ghbliapi.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
public class TextToImageRequest {

    //Getters for JSON serialization
    private final List<TextPrompt> text_prompts;
    private final double cfg_scale = 7;
    private final int height = 512;
    private final int width = 768;
    private final int samples = 1;
    private final int steps = 30;
    private final String style_preset;

    //Inner class for the text_prompts
    @Setter
    @Getter
    public static class TextPrompt {
        private String text;
        public TextPrompt(String text) {
            this.text = text;
        }

    }

    //constructor
    public TextToImageRequest(String text, String style) {
        this.text_prompts = List.of(new TextPrompt(text));
        this.style_preset = style;
    }

}
