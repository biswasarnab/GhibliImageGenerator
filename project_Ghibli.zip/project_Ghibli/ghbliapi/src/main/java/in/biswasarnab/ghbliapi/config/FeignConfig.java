//package in.biswasarnab.ghbliapi.config;
//
//import feign.codec.Encoder;
//import feign.form.spring.SpringFormEncoder;
//import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
//import org.springframework.cloud.openfeign.support.SpringEncoder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.client.RestTemplate;
//
////import javax.naming.spi.ObjectFactory;
//
//@Configuration
//public class FeignConfig {
//
//    @Bean
//    public Encoder feignFormEncoder() {
//        return new SpringFormEncoder(
//                new SpringEncoder(() -> new HttpMessageConverters(new RestTemplate().getMessageConverters())));
//    }
//}

//@Configuration
//public class FeignConfig {
//    @Bean
//    public Encoder feignFormEncoder(ObjectFactory messageConverters) {
//        return new SpringFormEncoder(new SpringEncoder((org.springframework.beans.factory.ObjectFactory<HttpMessageConverters>) messageConverters));
//    }
//}




package in.biswasarnab.ghbliapi.config;

import feign.codec.Encoder;
import feign.form.spring.SpringFormEncoder;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class FeignConfig {
    @Bean
    public Encoder multipartFormEncoder() {
        return new SpringFormEncoder(new SpringEncoder(() -> new HttpMessageConverters(new RestTemplate().getMessageConverters())));
    }
}