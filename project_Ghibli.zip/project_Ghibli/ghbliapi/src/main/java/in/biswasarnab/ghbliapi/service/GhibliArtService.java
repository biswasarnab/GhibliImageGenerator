package in.biswasarnab.ghbliapi.service;


import in.biswasarnab.ghbliapi.client.StabilityAIClient;
import in.biswasarnab.ghbliapi.dto.TextToImageRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class GhibliArtService {
    private final StabilityAIClient stabilityAIClient;
    private final String apiKey;

    public GhibliArtService(StabilityAIClient stabilityAIClient, @Value("${stability.api.key}") String apiKey) {
        this.stabilityAIClient = stabilityAIClient;
        this.apiKey = apiKey;
    }

    public byte[] createGhibliArt(MultipartFile image, String prompt) {
        String finalPrompt = prompt + ", in the beautiful, detailed anime style of studio ghibli.";
        String engineId = "stable-diffusion-v1-6";
        String stylePreset = "anime";

        return stabilityAIClient.generateImageFromImage(
                "Bearer " + apiKey,
                engineId,
                image,
                finalPrompt,
                stylePreset);
    }

//    public byte[] createGhibliArt(MultipartFile image, String prompt) {
//        // 1. Build the stylized prompt
//        String finalPrompt = prompt + ", in the beautiful, detailed anime style of studio ghibli.";
//
//        // 2. Specify the engine (ensure this matches a valid Stability ID)
//        String engineId = "stable-diffusion-v1-6";
//
//        // 3. Match the @RequestPart names exactly
//        return stabilityAIClient.generateImageFromImage(
//                "Bearer " + apiKey,
//                engineId,
//                image,        // This maps to @RequestPart("init_image")
//                finalPrompt,  // This maps to @RequestPart("text_prompts[0][text]")
//                "anime"       // This maps to @RequestPart("style_preset")
//        );
//    }


    public byte[] createGhibliArtFromText(String prompt, String style) {
        String finalPrompt = prompt + ", in the beautiful, detailed anime style of studio ghibli.";
        String engineId = "stable-diffusion-v1-6";
        String stylePreset = style.equals("general") ? "anime" : style.replace("_", "-");

        TextToImageRequest requestPayload = new TextToImageRequest(finalPrompt, stylePreset);

        return stabilityAIClient.generateImageFromText(
                "Bearer " + apiKey,
                engineId,
                requestPayload);
    }
}

