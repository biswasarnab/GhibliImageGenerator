//package in.biswasarnab.ghbliapi.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//
//        http
//                .cors() // ✅ VERY IMPORTANT (connects your WebConfig)
//                .and()
//                .csrf().disable(); // ✅ disable CSRF for POST
//
//        return http.build();
//    }
//}
